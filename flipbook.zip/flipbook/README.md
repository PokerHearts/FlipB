# Flipbook Publishing System

A completely static flipbook system. No backend, no build step, no database.
Open `index.html` and go.

## How it works

| Layer | Technology |
|---|---|
| PDF rendering | PDF.js 3.11 (bundled in `/libs/`) |
| Page flip animation | StPageFlip 2.0 (bundled in `/libs/`) |
| Page image storage | IndexedDB (per-browser, persistent) |
| Book registry | localStorage |
| Typography | Inter (Google Fonts CDN) |

### Static-site limitation

Because this runs purely in the browser, **books are stored in your browser**
(IndexedDB for page images, localStorage for metadata). They persist across
sessions until you clear browser data. They are **not** shared between devices
or browsers.

This is the correct approach for a 100% static system. A backend would be
needed for cross-device sync.

## Workflow

1. Open `upload.html`
2. Fill in title, author, category
3. (Optional) upload a cover image
4. Select one or more PDFs
5. Choose: **separate books** or **merged into one**
6. Click **Publish** — pages are rendered in the background
7. Open `index.html` to see your library
8. Click any book → `viewer.html?book=<slug>` opens the flipbook

## Viewer controls

| Action | Shortcut |
|---|---|
| Next page | `→` / `↓` / `Page Down` |
| Prev page | `←` / `↑` / `Page Up` |
| First page | `Home` |
| Last page | `End` |
| Fullscreen | `F` |
| Zoom in/out | `+` / `-` |
| Zoom to page | Double-click page |
| Close zoom | `Esc` or click overlay |

## Hosting on GitHub Pages

1. Push this folder to a GitHub repository
2. Enable GitHub Pages (Settings → Pages → source: root)
3. Open `https://<user>.github.io/<repo>/`

No build step, no configuration needed.

## Project structure

```
/
├── index.html          Library
├── viewer.html         Single universal viewer (viewer.html?book=slug)
├── upload.html         Publish page
├── css/
│   ├── main.css        Design tokens, components, library layout
│   ├── viewer.css      Viewer-specific layout
│   └── upload.css      Upload form layout
├── js/
│   ├── library.js      Library controller
│   ├── viewer.js       Viewer controller
│   ├── upload.js       Upload/publish controller
│   └── modules/
│       ├── storage.js      IndexedDB + localStorage abstraction
│       ├── pdf-processor.js  PDF.js page rendering
│       ├── utils.js        Shared utilities
│       └── toast.js        Toast notifications
├── libs/
│   ├── pdf.min.js
│   ├── pdf.worker.min.js
│   └── page-flip.js
└── books/              (reserved for static book assets if needed)
```
