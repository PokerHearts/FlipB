/**
 * library.js – Controller for index.html
 */

import { getRegistry, getCoverDataURL, deleteBook }  from './modules/storage.js';
import { fmtDate, debounce, applyTheme, getTheme, toggleTheme } from './modules/utils.js';
import { toastSuccess } from './modules/toast.js';

// ─── DOM refs ─────────────────────────────────────────────────────────────

const grid         = document.getElementById('books-grid');
const emptyState   = document.getElementById('empty-state');
const searchInput  = document.getElementById('search-input');
const filterWrap   = document.getElementById('filter-chips');
const countEl      = document.getElementById('book-count');
const themeToggle  = document.getElementById('theme-toggle');

// ─── State ────────────────────────────────────────────────────────────────

let activeCategory = 'All';
let searchQuery    = '';

// ─── Init ─────────────────────────────────────────────────────────────────

applyTheme(getTheme());
themeToggle.addEventListener('click', () => toggleTheme());

render();

// ─── Search & filter ──────────────────────────────────────────────────────

searchInput.addEventListener('input', debounce(e => {
  searchQuery = e.target.value.toLowerCase().trim();
  render();
}, 200));

// ─── Render ───────────────────────────────────────────────────────────────

function render() {
  const books     = getRegistry();
  const categories = ['All', ...new Set(books.map(b => b.category).filter(Boolean))];
  renderFilters(categories);

  const filtered = books.filter(b => {
    const matchCat  = activeCategory === 'All' || b.category === activeCategory;
    const matchSearch = !searchQuery ||
      b.title.toLowerCase().includes(searchQuery) ||
      (b.author || '').toLowerCase().includes(searchQuery) ||
      (b.desc || '').toLowerCase().includes(searchQuery);
    return matchCat && matchSearch;
  });

  countEl.textContent = `${filtered.length} book${filtered.length !== 1 ? 's' : ''}`;

  grid.innerHTML = '';

  if (!filtered.length) {
    emptyState.classList.remove('hidden');
    return;
  }

  emptyState.classList.add('hidden');
  filtered.forEach(book => grid.appendChild(buildCard(book)));
}

function renderFilters(categories) {
  // Keep existing chips if categories haven't changed
  const existing = [...filterWrap.querySelectorAll('.chip')].map(c => c.dataset.cat);
  if (JSON.stringify(existing) === JSON.stringify(categories)) return;

  filterWrap.innerHTML = '';
  categories.forEach(cat => {
    const chip = document.createElement('button');
    chip.className = `chip${cat === activeCategory ? ' active' : ''}`;
    chip.dataset.cat = cat;
    chip.textContent = cat;
    chip.addEventListener('click', () => {
      activeCategory = cat;
      render();
    });
    filterWrap.appendChild(chip);
  });
}

function buildCard(book) {
  const coverURL = getCoverDataURL(book.slug);

  const card = document.createElement('div');
  card.className = 'book-card';
  card.setAttribute('role', 'article');
  card.setAttribute('aria-label', book.title);

  const coverHTML = coverURL
    ? `<img src="${coverURL}" alt="${book.title} cover" loading="lazy"/>`
    : `<div class="book-cover-placeholder">
         ${bookIcon()}
         <span class="text-xs text-muted">${book.sourceFiles?.[0] || 'PDF'}</span>
       </div>`;

  card.innerHTML = `
    <div class="book-cover">
      ${coverHTML}
      ${book.category ? `<span class="book-category-badge">${book.category}</span>` : ''}
    </div>
    <div class="book-info">
      <div class="book-title">${book.title}</div>
      ${book.author ? `<div class="book-author">by ${book.author}</div>` : '<div class="book-author">&nbsp;</div>'}
      <div class="book-meta">
        <span class="book-pages">${book.pages} pages · ${fmtDate(book.created)}</span>
        <button class="btn-open" data-slug="${book.slug}">Open</button>
      </div>
    </div>`;

  // Click card or Open button → open viewer
  const openViewer = () => {
    location.href = `viewer.html?book=${encodeURIComponent(book.slug)}`;
  };

  card.querySelector('.btn-open').addEventListener('click', e => {
    e.stopPropagation();
    openViewer();
  });

  card.addEventListener('click', openViewer);

  // Right-click → context menu with delete
  card.addEventListener('contextmenu', e => {
    e.preventDefault();
    showContextMenu(e.clientX, e.clientY, book);
  });

  return card;
}

// ─── Simple inline context menu ───────────────────────────────────────────

function showContextMenu(x, y, book) {
  removeContextMenu();

  const menu = document.createElement('div');
  menu.id = 'ctx-menu';
  menu.style.cssText = `
    position: fixed; left: ${x}px; top: ${y}px;
    background: var(--bg-card); border: 1px solid var(--border);
    border-radius: var(--radius-md); box-shadow: var(--shadow-lg);
    z-index: 999; min-width: 160px; overflow: hidden;
    animation: slideIn 0.15s ease;
  `;

  const items = [
    { label: 'Open Book', icon: '↗', action: () => { location.href = `viewer.html?book=${encodeURIComponent(book.slug)}`; } },
    { label: 'Delete Book', icon: '🗑', action: () => confirmDelete(book), danger: true },
  ];

  items.forEach(({ label, icon, action, danger }) => {
    const btn = document.createElement('button');
    btn.style.cssText = `
      display: flex; align-items: center; gap: 8px;
      width: 100%; padding: 10px 14px; font-size: 0.825rem;
      font-weight: 500; background: none; border: none; cursor: pointer;
      color: ${danger ? '#ef4444' : 'var(--text-primary)'};
      transition: background 0.15s;
      text-align: left;
    `;
    btn.onmouseenter = () => btn.style.background = 'var(--bg-input)';
    btn.onmouseleave = () => btn.style.background = 'none';
    btn.innerHTML = `<span>${icon}</span><span>${label}</span>`;
    btn.addEventListener('click', () => { removeContextMenu(); action(); });
    menu.appendChild(btn);
  });

  document.body.appendChild(menu);

  // Adjust if off-screen
  requestAnimationFrame(() => {
    const rect = menu.getBoundingClientRect();
    if (rect.right  > innerWidth)  menu.style.left = `${x - rect.width}px`;
    if (rect.bottom > innerHeight) menu.style.top  = `${y - rect.height}px`;
  });

  setTimeout(() => document.addEventListener('click', removeContextMenu, { once: true }), 0);
}

function removeContextMenu() {
  document.getElementById('ctx-menu')?.remove();
}

async function confirmDelete(book) {
  if (!confirm(`Delete "${book.title}"? This cannot be undone.`)) return;
  await deleteBook(book.slug);
  toastSuccess(`"${book.title}" deleted.`);
  render();
}

// ─── SVG icon ─────────────────────────────────────────────────────────────

function bookIcon() {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
  </svg>`;
}
