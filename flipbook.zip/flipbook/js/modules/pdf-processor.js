/**
 * pdf-processor.js – Renders PDF pages to image blobs using PDF.js.
 * Runs page-by-page to avoid freezing the main thread.
 */

const RENDER_SCALE = 1.8; // Good balance: quality vs memory
const RENDER_TYPE  = 'image/jpeg';
const RENDER_QUAL  = 0.88;

let _pdfjs = null;

function getPdfJs() {
  if (_pdfjs) return _pdfjs;
  // PDF.js attaches to globalThis.pdfjsLib when loaded as browser script
  if (typeof pdfjsLib === 'undefined') throw new Error('PDF.js not loaded');
  // Resolve worker path relative to the root, not the module file
  // ponytail: new URL is the correct static way to get absolute paths in modules
  const workerURL = new URL('../../libs/pdf.worker.min.js', import.meta.url).href;
  pdfjsLib.GlobalWorkerOptions.workerSrc = workerURL;
  _pdfjs = pdfjsLib;
  return _pdfjs;
}

/**
 * Load a PDF File object, return the PDFDocumentProxy.
 */
export async function loadPDF(file) {
  const pdfjs      = getPdfJs();
  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjs.getDocument({ data: arrayBuffer });
  return loadingTask.promise;
}

/**
 * Render a single page to a Blob.
 * @param {PDFDocumentProxy} pdfDoc
 * @param {number} pageNum – 1-based
 * @returns {Promise<Blob>}
 */
export async function renderPageToBlob(pdfDoc, pageNum) {
  const page     = await pdfDoc.getPage(pageNum);
  const viewport = page.getViewport({ scale: RENDER_SCALE });

  const canvas    = document.createElement('canvas');
  canvas.width    = viewport.width;
  canvas.height   = viewport.height;
  const ctx       = canvas.getContext('2d');

  await page.render({ canvasContext: ctx, viewport }).promise;
  page.cleanup();

  return new Promise(resolve => {
    canvas.toBlob(blob => resolve(blob), RENDER_TYPE, RENDER_QUAL);
  });
}

/**
 * Render ALL pages, calling onProgress(current, total) after each.
 * Yields to the event loop between pages so UI stays responsive.
 *
 * @param {File[]} files          – one or more PDF files
 * @param {function} onProgress   – (rendered, total) => void
 * @param {function} onPageReady  – (fileIndex, pageIndex, blob) => Promise<void>
 * @returns {Promise<{totalPages:number, pageDimensions:{w,h}}>}
 */
export async function processFiles(files, onProgress, onPageReady) {
  const pdfDocs = [];
  let totalPages = 0;

  for (const file of files) {
    const doc = await loadPDF(file);
    pdfDocs.push(doc);
    totalPages += doc.numPages;
  }

  let rendered   = 0;
  let firstDims  = null;
  let pageOffset = 0; // global page index across merged files

  for (let fi = 0; fi < pdfDocs.length; fi++) {
    const doc = pdfDocs[fi];
    for (let pn = 1; pn <= doc.numPages; pn++) {
      // Capture first page dimensions for StPageFlip
      if (!firstDims) {
        const page     = await doc.getPage(pn);
        const viewport = page.getViewport({ scale: RENDER_SCALE });
        firstDims = { w: Math.round(viewport.width), h: Math.round(viewport.height) };
        page.cleanup();
      }

      const blob = await renderPageToBlob(doc, pn);
      await onPageReady(fi, pageOffset, blob);

      rendered++;
      pageOffset++;
      onProgress(rendered, totalPages);

      // Yield to event loop every 4 pages
      if (rendered % 4 === 0) await yieldToMain();
    }
    doc.destroy();
  }

  return { totalPages, pageDimensions: firstDims };
}

function yieldToMain() {
  return new Promise(resolve => setTimeout(resolve, 0));
}

/**
 * Get the dimensions of the first page of a PDF file (without rendering).
 */
export async function getFirstPageDimensions(file) {
  const doc      = await loadPDF(file);
  const page     = await doc.getPage(1);
  const viewport = page.getViewport({ scale: RENDER_SCALE });
  page.cleanup();
  doc.destroy();
  return { w: Math.round(viewport.width), h: Math.round(viewport.height) };
}
