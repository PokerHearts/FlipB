/**
 * storage.js – All persistence lives here.
 * Books registry: localStorage (JSON, small metadata).
 * Page images:    IndexedDB (blobs, can be large).
 */

const DB_NAME    = 'flipbook_db';
const DB_VERSION = 1;
const STORE_NAME = 'pages';
const LS_KEY     = 'flipbook_registry';

// ─── IndexedDB ────────────────────────────────────────────────────────────

let _db = null;

function openDB() {
  if (_db) return Promise.resolve(_db);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = e => {
      e.target.result.createObjectStore(STORE_NAME);
    };
    req.onsuccess  = e => { _db = e.target.result; resolve(_db); };
    req.onerror    = e => reject(e.target.error);
  });
}

export async function savePageImage(bookSlug, pageIndex, blob) {
  const db   = await openDB();
  const key  = `${bookSlug}::${pageIndex}`;
  return new Promise((resolve, reject) => {
    const tx    = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req   = store.put(blob, key);
    req.onsuccess = () => resolve();
    req.onerror   = e => reject(e.target.error);
  });
}

export async function getPageImage(bookSlug, pageIndex) {
  const db  = await openDB();
  const key = `${bookSlug}::${pageIndex}`;
  return new Promise((resolve, reject) => {
    const tx    = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req   = store.get(key);
    req.onsuccess = e => resolve(e.target.result || null);
    req.onerror   = e => reject(e.target.error);
  });
}

export async function deleteBookImages(bookSlug) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx    = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req   = store.openCursor();
    const toDelete = [];
    req.onsuccess = e => {
      const cursor = e.target.result;
      if (cursor) {
        if (cursor.key.startsWith(`${bookSlug}::`)) toDelete.push(cursor.key);
        cursor.continue();
      } else {
        toDelete.forEach(k => store.delete(k));
        resolve();
      }
    };
    req.onerror = e => reject(e.target.error);
  });
}

// ─── Books Registry (localStorage) ───────────────────────────────────────

export function getRegistry() {
  try {
    return JSON.parse(localStorage.getItem(LS_KEY) || '[]');
  } catch {
    return [];
  }
}

export function saveRegistry(books) {
  localStorage.setItem(LS_KEY, JSON.stringify(books));
}

export function getBook(slug) {
  return getRegistry().find(b => b.slug === slug) || null;
}

export function addBook(meta) {
  const registry = getRegistry();
  const idx = registry.findIndex(b => b.slug === meta.slug);
  if (idx >= 0) registry[idx] = meta; // overwrite on re-publish
  else registry.unshift(meta);
  saveRegistry(registry);
}

export function deleteBook(slug) {
  const registry = getRegistry().filter(b => b.slug !== slug);
  saveRegistry(registry);
  return deleteBookImages(slug);
}

// ─── Cover Image ──────────────────────────────────────────────────────────

export function saveCoverDataURL(bookSlug, dataURL) {
  try {
    localStorage.setItem(`cover_${bookSlug}`, dataURL);
  } catch {
    // quota exceeded — cover just won't persist
  }
}

export function getCoverDataURL(bookSlug) {
  return localStorage.getItem(`cover_${bookSlug}`) || null;
}

export function deleteCover(bookSlug) {
  localStorage.removeItem(`cover_${bookSlug}`);
}
