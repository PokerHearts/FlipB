/**
 * upload.js – Controller for upload.html
 */

import { slugify, uniqueSlug, fmtBytes, getTheme, applyTheme, toggleTheme } from './modules/utils.js';
import { processFiles }                                                        from './modules/pdf-processor.js';
import { addBook, getRegistry, savePageImage, saveCoverDataURL }               from './modules/storage.js';
import { toastSuccess, toastError }                                            from './modules/toast.js';

// ─── DOM refs ─────────────────────────────────────────────────────────────

const form          = document.getElementById('upload-form');
const titleInput    = document.getElementById('book-title');
const authorInput   = document.getElementById('book-author');
const descInput     = document.getElementById('book-desc');
const categoryInput = document.getElementById('book-category');
const pdfInput      = document.getElementById('pdf-input');
const dropZone      = document.getElementById('drop-zone');
const fileList      = document.getElementById('file-list');
const coverInput    = document.getElementById('cover-input');
const coverPreview  = document.getElementById('cover-preview-img');
const coverPlaceholder = document.getElementById('cover-placeholder');
const modeRadios    = document.querySelectorAll('input[name="publish-mode"]');
const publishBtn    = document.getElementById('publish-btn');
const themeToggle   = document.getElementById('theme-toggle');

// Progress overlay
const progressOverlay  = document.getElementById('progress-overlay');
const progressBar      = document.getElementById('progress-bar');
const progressPct      = document.getElementById('progress-pct');
const progressSubtitle = document.getElementById('progress-subtitle');

// Summary sidebar
const summaryTitle    = document.getElementById('summary-title');
const summaryAuthor   = document.getElementById('summary-author');
const summaryCategory = document.getElementById('summary-category');
const summaryMode     = document.getElementById('summary-mode');
const summaryFiles    = document.getElementById('summary-files');
const publishedList   = document.getElementById('published-list');

let selectedFiles  = [];   // File[]
let coverDataURL   = null;

// ─── Init ─────────────────────────────────────────────────────────────────

applyTheme(getTheme());
renderPublishedList();

themeToggle.addEventListener('click', () => toggleTheme());

// ─── Cover image ──────────────────────────────────────────────────────────

coverInput.addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    coverDataURL = ev.target.result;
    coverPreview.src = coverDataURL;
    coverPreview.classList.remove('hidden');
    coverPlaceholder.classList.add('hidden');
  };
  reader.readAsDataURL(file);
});

// ─── File drop ────────────────────────────────────────────────────────────

dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  addFiles([...e.dataTransfer.files].filter(f => f.type === 'application/pdf'));
});

pdfInput.addEventListener('change', e => {
  addFiles([...e.target.files]);
  e.target.value = ''; // reset so same file can be re-added after remove
});

function addFiles(files) {
  for (const f of files) {
    if (selectedFiles.find(x => x.name === f.name && x.size === f.size)) continue;
    selectedFiles.push(f);
  }
  renderFileList();
  updateSummary();
}

function removeFile(idx) {
  selectedFiles.splice(idx, 1);
  renderFileList();
  updateSummary();
}

function renderFileList() {
  fileList.innerHTML = '';
  if (!selectedFiles.length) {
    fileList.classList.add('hidden');
    return;
  }
  fileList.classList.remove('hidden');
  selectedFiles.forEach((f, i) => {
    const item = document.createElement('div');
    item.className = 'file-item';
    item.innerHTML = `
      <div class="file-icon">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="9" y1="13" x2="15" y2="13"/>
          <line x1="9" y1="17" x2="13" y2="17"/>
        </svg>
      </div>
      <div class="file-details">
        <div class="file-name">${f.name}</div>
        <div class="file-size">${fmtBytes(f.size)}</div>
      </div>
      <button class="file-remove" data-idx="${i}" title="Remove">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>`;
    fileList.appendChild(item);
  });

  fileList.querySelectorAll('.file-remove').forEach(btn => {
    btn.addEventListener('click', () => removeFile(Number(btn.dataset.idx)));
  });
}

// ─── Summary ──────────────────────────────────────────────────────────────

function getMode() {
  return [...modeRadios].find(r => r.checked)?.value || 'separate';
}

function updateSummary() {
  summaryTitle.textContent    = titleInput.value || '—';
  summaryAuthor.textContent   = authorInput.value || '—';
  summaryCategory.textContent = categoryInput.value || '—';
  summaryMode.textContent     = getMode() === 'separate'
    ? `${selectedFiles.length} book${selectedFiles.length !== 1 ? 's' : ''}`
    : 'Merged into 1 book';
  summaryFiles.textContent    = selectedFiles.length;
}

[titleInput, authorInput, categoryInput, ...modeRadios].forEach(el =>
  el.addEventListener('input', updateSummary)
);
modeRadios.forEach(r => r.addEventListener('change', updateSummary));

// ─── Publish ──────────────────────────────────────────────────────────────

form.addEventListener('submit', async e => {
  e.preventDefault();

  const title    = titleInput.value.trim();
  const author   = authorInput.value.trim();
  const desc     = descInput.value.trim();
  const category = categoryInput.value;
  const mode     = getMode();

  if (!title)                { toastError('Book title is required.'); return; }
  if (!selectedFiles.length) { toastError('Please upload at least one PDF.'); return; }

  publishBtn.disabled = true;
  showProgress('Processing PDFs…', 0);

  try {
    const existingSlugs = getRegistry().map(b => b.slug);

    if (mode === 'merge') {
      await publishMerged({ title, author, desc, category, existingSlugs });
    } else {
      await publishSeparate({ title, author, desc, category, existingSlugs });
    }

    hideProgress();
    resetForm();
    renderPublishedList();
    toastSuccess('Published successfully!');
  } catch (err) {
    console.error(err);
    hideProgress();
    toastError('Something went wrong: ' + err.message);
  } finally {
    publishBtn.disabled = false;
  }
});

async function publishMerged({ title, author, desc, category, existingSlugs }) {
  const baseSlug = slugify(title);
  const slug     = uniqueSlug(baseSlug, existingSlugs);

  let totalRendered = 0;
  let grandTotal    = 0;
  // Count total pages first (quick load)
  for (const f of selectedFiles) {
    const ab  = await f.arrayBuffer();
    const doc = await pdfjsLib.getDocument({ data: ab }).promise;
    grandTotal += doc.numPages;
    doc.destroy();
  }

  const { totalPages, pageDimensions } = await processFiles(
    selectedFiles,
    (rendered, total) => {
      totalRendered = rendered;
      showProgress(`Rendering page ${rendered} of ${total}…`, rendered / total);
    },
    async (_fi, globalIdx, blob) => {
      await savePageImage(slug, globalIdx, blob);
    }
  );

  const meta = {
    slug, title, author, desc, category,
    pages: totalPages,
    pageDimensions,
    created: Date.now(),
    cover: !!coverDataURL,
    sourceFiles: selectedFiles.map(f => f.name),
  };

  addBook(meta);
  if (coverDataURL) saveCoverDataURL(slug, coverDataURL);
}

async function publishSeparate({ title, author, desc, category, existingSlugs }) {
  for (let fi = 0; fi < selectedFiles.length; fi++) {
    const file      = selectedFiles[fi];
    const rawTitle  = selectedFiles.length > 1
      ? file.name.replace(/\.pdf$/i, '')
      : title;
    const bookTitle = selectedFiles.length > 1
      ? (title ? `${title}: ${rawTitle}` : rawTitle)
      : title;
    const baseSlug  = slugify(rawTitle);
    const slug      = uniqueSlug(baseSlug, existingSlugs);
    existingSlugs.push(slug); // prevent collision across loop

    const { totalPages, pageDimensions } = await processFiles(
      [file],
      (rendered, total) => {
        const overall = fi * 100; // rough progress across files
        showProgress(
          `Book ${fi + 1}/${selectedFiles.length}: page ${rendered}/${total}`,
          (fi + rendered / total) / selectedFiles.length
        );
      },
      async (_fi, pageIdx, blob) => {
        await savePageImage(slug, pageIdx, blob);
      }
    );

    const meta = {
      slug, title: bookTitle, author, desc, category,
      pages: totalPages,
      pageDimensions,
      created: Date.now(),
      cover: fi === 0 && !!coverDataURL,
      sourceFiles: [file.name],
    };

    addBook(meta);
    if (fi === 0 && coverDataURL) saveCoverDataURL(slug, coverDataURL);
  }
}

// ─── Progress helpers ──────────────────────────────────────────────────────

function showProgress(msg, fraction) {
  progressSubtitle.textContent = msg;
  const pct = Math.round(fraction * 100);
  progressBar.style.width = `${pct}%`;
  progressPct.textContent = `${pct}%`;
  progressOverlay.classList.add('active');
}

function hideProgress() {
  progressOverlay.classList.remove('active');
}

// ─── Reset form ───────────────────────────────────────────────────────────

function resetForm() {
  titleInput.value = '';
  authorInput.value = '';
  descInput.value = '';
  categoryInput.value = 'General';
  selectedFiles = [];
  coverDataURL  = null;
  coverPreview.classList.add('hidden');
  coverPlaceholder.classList.remove('hidden');
  renderFileList();
  updateSummary();
}

// ─── Published list ───────────────────────────────────────────────────────

function renderPublishedList() {
  const books = getRegistry().slice(0, 5);
  publishedList.innerHTML = '';

  if (!books.length) {
    publishedList.innerHTML = '<p class="text-muted text-sm">No books published yet.</p>';
    return;
  }

  books.forEach(b => {
    const item = document.createElement('div');
    item.className = 'published-item';
    item.innerHTML = `
      <span class="published-dot"></span>
      <a href="viewer.html?book=${encodeURIComponent(b.slug)}" target="_blank">${b.title}</a>
      <span class="text-muted text-xs">${b.pages}p</span>`;
    publishedList.appendChild(item);
  });
}

// Initial summary update
updateSummary();
