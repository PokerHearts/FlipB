/**
 * viewer.js – Controller for viewer.html
 * Loads book metadata + renders pages from IndexedDB into StPageFlip.
 */

import { getBook, getPageImage, getCoverDataURL } from './modules/storage.js';
import { getParam, applyTheme, getTheme, toggleTheme, tempBlobURL, show, hide } from './modules/utils.js';
import { toastError, toastInfo } from './modules/toast.js';

// ─── DOM refs ─────────────────────────────────────────────────────────────

const loadingScreen  = document.getElementById('viewer-loading');
const loadingText    = document.getElementById('loading-text');
const flipbookEl     = document.getElementById('flipbook');
const flipbookWrap   = document.getElementById('flipbook-container');
const pageCounter    = document.getElementById('page-counter');
const progressBar    = document.getElementById('viewer-progress');
const btnPrev        = document.getElementById('btn-prev');
const btnNext        = document.getElementById('btn-next');
const btnFullscreen  = document.getElementById('btn-fullscreen');
const btnZoomIn      = document.getElementById('btn-zoom-in');
const btnZoomOut     = document.getElementById('btn-zoom-out');
const zoomLabel      = document.getElementById('zoom-label');
const themeToggle    = document.getElementById('theme-toggle');
const navTitle       = document.getElementById('nav-title');
const navAuthor      = document.getElementById('nav-author');
const zoomOverlay    = document.getElementById('zoom-overlay');
const zoomImg        = document.getElementById('zoom-img');
const viewerPage     = document.getElementById('viewer-page');

// ─── State ────────────────────────────────────────────────────────────────

let pageFlip    = null;
let book        = null;
let totalPages  = 0;
let zoomLevel   = 1;
let pageURLs    = [];   // blob URLs for each page image

const PREFETCH_AHEAD = 4; // pages to prefetch beyond current spread

// ─── Init ─────────────────────────────────────────────────────────────────

applyTheme(getTheme());
themeToggle.addEventListener('click', () => toggleTheme());

const slug = getParam('book');
if (!slug) {
  showError('No book specified. Go back to the library.');
} else {
  init(slug);
}

// ─── Security ─────────────────────────────────────────────────────────────

document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('dragstart',   e => e.preventDefault());
document.addEventListener('selectstart', e => { if (!isInput(e.target)) e.preventDefault(); });
document.addEventListener('keydown', e => {
  // Block Ctrl+S, Ctrl+P, Ctrl+U
  if (e.ctrlKey && ['s','p','u'].includes(e.key.toLowerCase())) e.preventDefault();
});

function isInput(el) {
  return el.matches('input, textarea, [contenteditable]');
}

// ─── Main init ────────────────────────────────────────────────────────────

async function init(slug) {
  book = getBook(slug);
  if (!book) {
    showError(`Book "${slug}" not found. It may have been deleted.`);
    return;
  }

  document.title = `${book.title} — Flipbook`;
  navTitle.textContent  = book.title;
  navAuthor.textContent = book.author ? `by ${book.author}` : '';
  totalPages = book.pages;

  setLoadingText('Loading pages…');
  await loadAndRender();
}

async function loadAndRender() {
  // Stage dimensions
  const stageW = flipbookWrap.clientWidth  - 16;
  const stageH = flipbookWrap.clientHeight - 16;

  // Determine page size from book meta or fall back to A4 ratio
  const srcW = book.pageDimensions?.w || 595;
  const srcH = book.pageDimensions?.h || 842;
  const ratio = srcH / srcW;

  // Fit a two-page spread in available space
  // ponytail: simple ratio fit; doesn't account for portrait-only mode on mobile
  let pageW, pageH;
  const isMobile = window.innerWidth < 640;

  if (isMobile) {
    // Single page on mobile
    pageW = Math.min(stageW - 8, 380);
    pageH = Math.round(pageW * ratio);
  } else {
    const spreadW = Math.min(stageW, 1000);
    pageW = Math.floor(spreadW / 2);
    pageH = Math.min(Math.round(pageW * ratio), stageH - 8);
    pageW = Math.round(pageH / ratio);
  }

  // Preload first page so viewer isn't blank
  const firstBlob = await getPageImage(book.slug, 0);
  if (!firstBlob) {
    showError('Page data not found. The book may be corrupted or was published in another browser.');
    return;
  }

  const firstURL = tempBlobURL(firstBlob);

  // Initialize StPageFlip
  // PageFlip is available on globalThis from the browser bundle
  pageFlip = new St.PageFlip(flipbookEl, {
    width:      pageW,
    height:     pageH,
    size:       'fixed',
    minWidth:   isMobile ? pageW : pageW * 2,
    maxWidth:   isMobile ? pageW : pageW * 2,
    minHeight:  pageH,
    maxHeight:  pageH,
    maxShadowOpacity: 0.5,
    showCover:  true,
    mobileScrollSupport: true,
    swipeDistance: 30,
    usePortrait: isMobile,
    autoSize:    false,
  });

  // Build placeholder image array — real URLs loaded on demand
  const placeholderSrc = makeBlankDataURL(pageW, pageH);
  pageURLs = Array(totalPages).fill(placeholderSrc);
  pageURLs[0] = firstURL;

  pageFlip.loadFromImages(pageURLs);

  // Event listeners
  pageFlip.on('flip', e => {
    updatePageUI(e.data);
    prefetchAround(e.data);
  });

  pageFlip.on('changeState', e => {
    if (e.data === 'read') prefetchAround(pageFlip.getCurrentPageIndex());
  });

  // Hide loading screen after StPageFlip initializes
  setTimeout(() => {
    loadingScreen.classList.add('hidden');
    prefetchAround(0);
    updatePageUI(0);
  }, 300);

  // Keyboard navigation
  document.addEventListener('keydown', onKeydown);

  // Double-click zoom
  flipbookEl.addEventListener('dblclick', onDoubleClick);

  // Zoom overlay dismiss
  zoomOverlay.addEventListener('click', () => zoomOverlay.classList.remove('active'));
}

// ─── Prefetch ──────────────────────────────────────────────────────────────
// ponytail: updateFromImages re-initialises the whole collection each call.
// Ceiling: O(totalPages) per prefetch trigger. Fine for ≤500 pages; for
// multi-thousand page books, a custom canvas renderer per page would be needed.

let prefetchPending = false;

async function prefetchAround(pageIndex) {
  if (prefetchPending) return;
  prefetchPending = true;

  const start = Math.max(0, pageIndex - 1);
  const end   = Math.min(totalPages - 1, pageIndex + PREFETCH_AHEAD);
  let changed = false;

  for (let i = start; i <= end; i++) {
    if (!pageURLs[i].startsWith('data:image/gif')) continue; // already loaded

    const blob = await getPageImage(book.slug, i);
    if (!blob) continue;

    pageURLs[i] = tempBlobURL(blob);
    changed = true;
  }

  // Also ensure current page and adjacent are loaded
  if (changed && pageFlip) {
    try {
      pageFlip.updateFromImages(pageURLs);
    } catch {
      // Swallow; viewer still works with placeholder until user flips
    }
  }

  prefetchPending = false;
}

// ─── UI Updates ───────────────────────────────────────────────────────────

function updatePageUI(pageIndex) {
  const current = pageIndex + 1;
  pageCounter.textContent = `${current} / ${totalPages}`;
  const pct = (pageIndex / Math.max(1, totalPages - 1)) * 100;
  progressBar.style.width = `${pct}%`;
}

// ─── Controls ─────────────────────────────────────────────────────────────

btnPrev.addEventListener('click', () => pageFlip?.flipPrev());
btnNext.addEventListener('click', () => pageFlip?.flipNext());

document.getElementById('btn-first').addEventListener('click', () => pageFlip?.flip(0));
document.getElementById('btn-last').addEventListener('click',  () => pageFlip?.flip(totalPages - 1));

btnFullscreen.addEventListener('click', toggleFullscreen);

btnZoomIn.addEventListener('click',  () => adjustZoom(0.25));
btnZoomOut.addEventListener('click', () => adjustZoom(-0.25));

function adjustZoom(delta) {
  zoomLevel = Math.max(0.5, Math.min(2.5, zoomLevel + delta));
  flipbookEl.style.transform = `scale(${zoomLevel})`;
  flipbookEl.style.transformOrigin = 'center center';
  zoomLabel.textContent = `${Math.round(zoomLevel * 100)}%`;
}

function onKeydown(e) {
  if (!pageFlip) return;
  switch (e.key) {
    case 'ArrowRight': case 'ArrowDown': case 'PageDown':
      pageFlip.flipNext(); break;
    case 'ArrowLeft': case 'ArrowUp': case 'PageUp':
      pageFlip.flipPrev(); break;
    case 'Home': pageFlip.flip(0); break;
    case 'End':  pageFlip.flip(totalPages - 1); break;
    case 'f': case 'F': toggleFullscreen(); break;
    case '+': case '=': adjustZoom(0.25); break;
    case '-': case '_': adjustZoom(-0.25); break;
    case 'Escape': zoomOverlay.classList.remove('active'); break;
  }
}

// ─── Double-click zoom ────────────────────────────────────────────────────

async function onDoubleClick(e) {
  // Which page is visible?
  const pageIndex = pageFlip?.getCurrentPageIndex() ?? 0;
  const blob      = await getPageImage(book.slug, pageIndex);
  if (!blob) return;

  const url = tempBlobURL(blob);
  zoomImg.src = url;
  zoomOverlay.classList.add('active');
}

// ─── Fullscreen ───────────────────────────────────────────────────────────

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    viewerPage.requestFullscreen?.() || viewerPage.webkitRequestFullscreen?.();
  } else {
    document.exitFullscreen?.() || document.webkitExitFullscreen?.();
  }
}

document.addEventListener('fullscreenchange', () => {
  const icon = btnFullscreen.querySelector('svg');
  if (document.fullscreenElement) {
    icon.innerHTML = exitFsIcon();
  } else {
    icon.innerHTML = enterFsIcon();
  }
});

// ─── Helpers ──────────────────────────────────────────────────────────────

function makeBlankDataURL(w, h) {
  // 1×1 transparent gif stretched — placeholder before real image loads
  return 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
}

function showError(msg) {
  loadingText.textContent = msg;
  loadingScreen.classList.remove('hidden');
  // Replace spinner with error icon
  document.querySelector('.loader-ring').style.display = 'none';
  toastError(msg);
}

function setLoadingText(msg) { loadingText.textContent = msg; }

function enterFsIcon() {
  return `<path stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
    d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>`;
}

function exitFsIcon() {
  return `<path stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
    d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/>`;
}
